import { Component } from '@angular/core';

@Component({
  selector: 'app-meter-size',
  templateUrl: './meter-size.component.html',
  styleUrls: ['./meter-size.component.scss']
})
export class MeterSizeComponent {

}
