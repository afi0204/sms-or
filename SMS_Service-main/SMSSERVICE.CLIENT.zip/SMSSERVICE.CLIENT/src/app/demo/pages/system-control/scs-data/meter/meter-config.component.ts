import { Component } from '@angular/core';

@Component({
  selector: 'app-meter-config',
  templateUrl: './meter-config.component.html',
  styleUrls: ['./meter-config.component.scss']
})
export class MeterConfigComponent {

}
