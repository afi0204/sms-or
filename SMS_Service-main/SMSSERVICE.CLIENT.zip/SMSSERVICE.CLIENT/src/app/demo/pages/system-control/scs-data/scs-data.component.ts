import { CommonModule } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import {  SharedModule } from 'primeng/api';
import { TableModule } from 'primeng/table';
import { TabViewModule } from 'primeng/tabview';

@Component({
  selector: 'app-scs-data',

  templateUrl: './scs-data.component.html',
  styleUrls: ['./scs-data.component.scss']
})
export default class ScsDataComponent implements OnInit {

ngOnInit(): void {
  
}

}
