export interface IUnsentGetDto {

  id :string,
  content:string,
  messageStatus:string,
  language:string,
  messageGroup:string,
  isApproved:boolean,
  textSize:number,
  numberOfCustomer:number

}
