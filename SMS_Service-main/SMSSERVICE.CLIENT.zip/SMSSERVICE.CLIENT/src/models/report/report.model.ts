export interface IReportGetDto {

  groupName:string,
  //organizationId:string,
  organizationName:string,
  messageStatus:string,
  Language:string,
  Content:string,
  //TextSize:string,
  NumberOfCustomer:string,
  createdDate:string,
  unSentCount:string

}
